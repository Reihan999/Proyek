import android.os.Build
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.empty.tugasproyek.Country
import com.empty.tugasproyek.ListCountryAdapter
import com.empty.tugasproyek.R

class MainActivity : AppCompatActivity() {
    private lateinit var rvCountry: RecyclerView
    private val list = ArrayList<Country>()



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        rvCountry = findViewById(R.id.rv_country)
        rvCountry.setHasFixedSize(true)
        list.addAll(getListCountry())
        showRecyclerList()
    }
        private fun showSelectedCountry(country: Country) {
        Toast.makeText(this, "Kamu memilih " + country.name, Toast.LENGTH_SHORT).show()
    }

    private fun showRecyclerList() {
        rvCountry.layoutManager = LinearLayoutManager(this)
        val listCountryAdapter = ListCountryAdapter(list)
        rvCountry.adapter = listCountryAdapter

        listCountryAdapter.setOnItemClickCallback(object : ListCountryAdapter.OnItemClickCallback {
            override fun onItemClicked(data: Country) {
                showSelectedCountry(data)
            }
        })
    }


    private fun getListCountry(): ArrayList<Country> {
        val dataName = resources.getStringArray(R.array.data_name)
        val dataDescription = resources.getStringArray(R.array.data_description)
        val dataPhoto = resources.obtainTypedArray(R.array.data_photo)
        val listCountry = ArrayList<Country>()

        for (i in dataName.indices) {
            val country = Country(dataName[i], dataDescription[i], dataPhoto.getResourceId(i, -1))
            listCountry.add(country)
        }
        dataPhoto.recycle()
        return listCountry
    }

}

