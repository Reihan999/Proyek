package com.empty.tugasproyek

import android.os.Build
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class CountryActivity2 : AppCompatActivity() {
    companion object {
        const val key_country = "country_key"
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_country2)
        val dataCountry = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra<Country>(key_country, Country::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra<Country>(key_country)
        }

        dataCountry?.let {
            val tvDetailName = findViewById<TextView>(R.id.tv_main_name)
            val tvDetailDescription = findViewById<TextView>(R.id.tv_main_description)
            val ivDetailPhoto = findViewById<ImageView>(R.id.iv_main_photo)

            tvDetailName.text = it.name
            tvDetailDescription.text = it.description
            ivDetailPhoto.setImageResource(it.photo)
        } ?: run {
            // Handle the case where dataCountry is null (e.g., show a default message)
            // Example: tvMainName.text = "No country data available"
        }

    }
        }

