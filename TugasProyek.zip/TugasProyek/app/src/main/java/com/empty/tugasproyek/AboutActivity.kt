package com.empty.tugasproyek

class AboutActivity {
}